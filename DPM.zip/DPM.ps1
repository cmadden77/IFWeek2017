Configuration DPM
{
  param ($MachineName)
Import-DscResource -ModuleName xPendingReboot;
  Node localhost
  {

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = �Present�
      Name = �Web-Asp-Net45�
    }

     WindowsFeature DotNet
    {
        Name = "NET-Framework-Core"
        Ensure = "Present"
    }

     WindowsFeature SiS
    {
        Name = "FS-Data-Deduplication"
        Ensure = "Present"
    }

	# Reboot node if necessary
	xPendingReboot RebootPostInstallSiS
    {
        Name      = "AfterSiS"
		DependsOn = "[xPSWindowsUpdate]SiS"
    }
  }
} 